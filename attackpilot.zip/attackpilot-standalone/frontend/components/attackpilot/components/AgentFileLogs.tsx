import React, { useEffect, useMemo, useState } from "react";
import { App as AntdApp, Button, Empty, Space, Spin, Tag, Typography } from "antd";
import { Copy, FileText, RefreshCcw } from "lucide-react";
import { getAgentLogFile, listAgentLogFiles } from "../services/api";
import { AgentLogFileMeta, AgentLogFileResponse } from "../types";
import { agentDisplayName } from "../utils/presentation";

interface AgentFileLogsProps {
  taskId: string;
}

function formatBytes(size: number) {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / 1024 / 1024).toFixed(1)} MB`;
}

function getFileLabel(file: AgentLogFileMeta) {
  return agentDisplayName(file.agent || file.name.replace(/\.log$/i, ""));
}

const AgentFileLogs: React.FC<AgentFileLogsProps> = ({ taskId }) => {
  const { message } = AntdApp.useApp();
  const [files, setFiles] = useState<AgentLogFileMeta[]>([]);
  const [logDir, setLogDir] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState("");
  const [selectedLog, setSelectedLog] = useState<AgentLogFileResponse | null>(null);
  const [loadingList, setLoadingList] = useState(true);
  const [revision, setRevision] = useState(0);
  const [settledFileId, setSettledFileId] = useState("");
  const loadingFile = !!selectedId && settledFileId !== selectedId;

  const selectedFile = useMemo(
    () => files.find((file) => file.id === selectedId) ?? null,
    [files, selectedId],
  );

  useEffect(() => {
    let alive = true;
    listAgentLogFiles(taskId).then(response => {
      if (!alive) return;
      setFiles(response.files);
      setLogDir(response.log_dir);
      setSelectedId(response.files.find(file => file.size > 0)?.id ?? response.files[0]?.id ?? "");
    }).catch(() => { if (alive) message.error("日志文件列表加载失败"); })
      .finally(() => { if (alive) setLoadingList(false); });
    return () => { alive = false; };
  }, [message, taskId, revision]);

  useEffect(() => {
    if (!selectedId) return;
    let alive = true;
    getAgentLogFile(taskId, selectedId).then(result => { if (alive) setSelectedLog(result); })
      .catch(() => { if (alive) { setSelectedLog(null); message.error("智能体日志文件加载失败"); } })
      .finally(() => { if (alive) setSettledFileId(selectedId); });
    return () => { alive = false; };
  }, [message, taskId, selectedId, revision]);

  const loadList = () => { setLoadingList(true); setSettledFileId(""); setRevision(value => value + 1); };
  const handleSelect = (fileId: string) => { setSelectedId(fileId); };

  const handleCopy = async () => {
    if (!selectedLog?.content) return;
    await navigator.clipboard.writeText(selectedLog.content);
    message.success("日志已复制");
  };

  if (loadingList && files.length === 0) {
    return (
      <div className="center-loading">
        <Spin />
      </div>
    );
  }

  if (files.length === 0) {
    return (
      <div className="file-log-panel">
        <div className="file-log-header">
          <div>
            <Typography.Text strong>智能体日志文件</Typography.Text>
            <Typography.Text type="secondary">未找到持久化日志文件。</Typography.Text>
          </div>
          <Button size="small" icon={<RefreshCcw size={14} />} onClick={loadList} />
        </div>
        <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="暂无日志文件" />
      </div>
    );
  }

  return (
    <div className="file-log-panel">
      <div className="file-log-header">
        <div>
          <Typography.Text strong>智能体日志文件</Typography.Text>
          <Typography.Text type="secondary" className="text-mono">
            {logDir ?? "日志目录不可用"}
          </Typography.Text>
        </div>
        <Button size="small" icon={<RefreshCcw size={14} />} loading={loadingList} onClick={loadList} />
      </div>

      <div className="file-log-list">
        {files.map((file) => (
          <button
            className={`file-log-row ${file.id === selectedId ? "selected" : ""}`}
            key={file.id}
            type="button"
            onClick={() => handleSelect(file.id)}
          >
            <span>
              <FileText size={14} />
              {getFileLabel(file)}
            </span>
            <small>{formatBytes(file.size)}</small>
          </button>
        ))}
      </div>

      <div className="file-log-main">
        <div className="file-log-meta">
          <Space size={6} wrap>
            <Tag>{agentDisplayName(selectedFile?.agent)}</Tag>
            <Tag>{selectedFile ? formatBytes(selectedFile.size) : "暂无"}</Tag>
            {selectedLog?.truncated ? <Tag color="warning">内容已截断</Tag> : null}
          </Space>
          <Button size="small" icon={<Copy size={13} />} disabled={loadingFile || !selectedLog?.content} onClick={handleCopy}>
            复制
          </Button>
        </div>

        <div className="file-log-viewer">
          {loadingFile ? (
            <div className="center-loading">
              <Spin />
            </div>
          ) : selectedLog?.content ? (
            <pre>{selectedLog.content}</pre>
          ) : (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="日志文件为空" />
          )}
        </div>
      </div>
    </div>
  );
};

export default AgentFileLogs;
