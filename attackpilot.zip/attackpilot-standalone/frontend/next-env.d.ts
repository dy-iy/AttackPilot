/// <reference types="next" />
/// <reference types="next/image-types/global" />

// Next.js maintains this file when preparing route types.
