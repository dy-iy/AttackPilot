"""Writable standalone data, kept outside the source and public fixtures."""
import os
from pathlib import Path
from dotenv import load_dotenv

BACKEND_ROOT = Path(__file__).resolve().parents[1]
load_dotenv(BACKEND_ROOT / ".env")


def resolve_path(value: str, default: Path) -> Path:
    path = Path(value.strip()) if value.strip() else default
    return (path if path.is_absolute() else BACKEND_ROOT / path).resolve()


RUNTIME_ROOT = resolve_path(os.getenv("APP_RUNTIME_DIR", ""), BACKEND_ROOT / "runtime")


def runtime_file(setting: str, filename: str) -> Path:
    return resolve_path(os.getenv(setting, ""), RUNTIME_ROOT / filename)
