from typing import Union

from web3 import Web3

TOKEN20_721_TRANSFER_TOPIC = '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'


def parse_token_transfer(log: dict) -> Union[dict, None]:
    if log['topics'][0] == TOKEN20_721_TRANSFER_TOPIC:
        # load log topics
        topics = log.get('topics')
        if any([
            topics is None,
            len(topics) < 1,
            topics[0] != TOKEN20_721_TRANSFER_TOPIC
        ]):
            return

        # load log data
        data = log.get('data')
        topics_with_data = topics + split_to_words(data)
        if len(topics_with_data) != 4:
            return
        return {
            "from": word_to_address(topics_with_data[1]),
            "to": word_to_address(topics_with_data[2]),
            "value": topics_with_data[3],
            "symbol": log['address'],
        }


def parse_bytes_data(data: bytes, output_types: list) -> Union[tuple, None]:
    """
    Parse the web3 bytes data from the given output types.

    :param data:
    :param output_types:
    :return:
    """
    if not isinstance(data, str) or data == '0x' or not data:
        return None

    # parse using web3
    try:
        data = bytes.fromhex(data[2:])
        result = Web3().codec.decode(output_types, data)
    except Exception as e:
        print(e)
        return None
    return result


def bytes_to_string(data: bytes):
    if data is None:
        return ''
    try:
        b = data.decode('utf-8')
    except UnicodeDecodeError as _:
        return ''
    return b


def hex_to_dec(hex_string: str) -> int:
    if hex_string is None:
        return -1
    try:
        return int(hex_string, 16)
    except ValueError:
        return -1


def word_to_address(param: str) -> str:
    if param is None:
        return ''
    if len(param) >= 40:
        return ('0x' + param[-40:]).lower()
    else:
        return param.lower()


def chunk_string(string, length):
    return (string[0 + i:length + i] for i in range(0, len(string), length))


def split_to_words(data: str) -> list:
    if data and len(data) > 2:
        data_without_0x = data[2:]
        words = list(chunk_string(data_without_0x, 64))
        words_with_0x = list(map(lambda word: '0x' + word, words))
        return words_with_0x
    return []
