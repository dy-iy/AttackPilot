"""Standalone AttackPilot API; no unrelated product services are imported."""
from contextlib import asynccontextmanager
import json
import logging
import os
from pathlib import Path
import re
import time
import uuid

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent / ".env")

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.auth import SESSION_COOKIE_NAME, router as auth_router
from app.attackpilot.api import router as attackpilot_router
from app.services.csrf_service import csrf_request_allowed
from app.services.rate_limit_service import check_rate_limit
from app.services.request_body_limit_service import max_request_body_bytes, request_body_exceeds_limit
from app.services.request_security_service import request_client_identity

logger = logging.getLogger("attackpilot.api")


@asynccontextmanager
async def lifespan(_app: FastAPI):
    from app.attackpilot import settings, store
    from app.attackpilot.manager import manager

    seed = settings.PACKAGE_ROOT / "data/demo-seed.json"
    if seed.is_file():
        store.import_seed(json.loads(seed.read_text(encoding="utf-8")))
    await manager.start()
    try:
        yield
    finally:
        await manager.stop()


def cors_origins() -> list[str]:
    configured = os.getenv("CORS_ALLOWED_ORIGINS", "").strip()
    origins = configured.split(",") if configured else ["http://localhost:3000", "http://127.0.0.1:3000"]
    origins = list(dict.fromkeys(origin.strip() for origin in origins if origin.strip()))
    if "*" in origins:
        raise ValueError("CORS_ALLOWED_ORIGINS must list explicit origins when session cookies are enabled")
    return origins


app = FastAPI(title="AttackPilot", version="1.0.0", lifespan=lifespan)


@app.exception_handler(RequestValidationError)
async def validation_error_handler(_request: Request, exc: RequestValidationError):
    return JSONResponse(status_code=422, content={"detail": [
        {"loc": list(error["loc"]), "msg": error["msg"], "type": error["type"]}
        for error in exc.errors()
    ]})


@app.middleware("http")
async def operational_headers(request: Request, call_next):
    candidate = request.headers.get("x-request-id", "")
    request_id = candidate if re.fullmatch(r"[A-Za-z0-9._-]{1,128}", candidate) else uuid.uuid4().hex
    started = time.perf_counter()
    decision = None
    if await request_body_exceeds_limit(request, max_request_body_bytes()):
        response = JSONResponse(status_code=413, content={"detail": "Request body too large."})
    elif not csrf_request_allowed(method=request.method, cookies=request.cookies,
                                  headers=request.headers, session_cookie_name=SESSION_COOKIE_NAME):
        response = JSONResponse(status_code=403, content={"detail": "Missing CSRF protection header for session-authenticated mutation."})
    else:
        identity = request_client_identity(request.client.host if request.client else "", request.headers)
        decision = check_rate_limit(identity=identity, path=request.url.path, method=request.method)
        if not decision.allowed:
            response = JSONResponse(status_code=429, content={
                "detail": "Too many requests. Please retry later.",
                "rate_limit": {"rule": decision.rule_name, "limit": decision.limit,
                               "retry_after_seconds": decision.retry_after_seconds},
            }, headers={"Retry-After": str(decision.retry_after_seconds)})
        else:
            try:
                response = await call_next(request)
            except Exception:
                logger.exception("request_failed", extra={"request_id": request_id, "path": request.url.path})
                response = JSONResponse(status_code=500, content={
                    "detail": "Internal server error. Please retry later.", "request_id": request_id,
                })
    if decision and decision.rule_name:
        response.headers["X-RateLimit-Limit"] = str(decision.limit)
        response.headers["X-RateLimit-Remaining"] = str(decision.remaining)
        response.headers["X-RateLimit-Reset"] = str(decision.reset_seconds)
    response.headers["X-Request-ID"] = request_id
    response.headers["X-Process-Time-Ms"] = f"{(time.perf_counter() - started) * 1000:.1f}"
    if request.url.path.startswith("/api/"):
        response.headers.setdefault("Cache-Control", "no-store")
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    return response


# Install CORS outside the operational middleware so even denied requests expose
# the explicit allowed-origin response headers without permitting other origins.
app.add_middleware(CORSMiddleware, allow_origins=cors_origins(), allow_credentials=True,
                   allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
                   allow_headers=["Content-Type", "X-CryptoRisk-CSRF", "X-Request-ID", "Last-Event-ID"],
                   expose_headers=["X-Request-ID", "Retry-After", "X-RateLimit-Remaining"])
app.include_router(auth_router)
app.include_router(attackpilot_router)


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "attackpilot"}
